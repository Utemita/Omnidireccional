// motor.h

#ifndef MOTOR_H
#define MOTOR_H

#include <Arduino.h>

struct MotorDC {
  int A;
  int B;
  int PWM;	
  int Dir1;
  int Dir2;
  volatile bool bandera;

  volatile int Aval;
  volatile int Bval;
  volatile int counter;

  float vel, velFilt;

  float kp, ki, kd, Ts;
  float ea;
  float Aka;
  float ref;
  unsigned long timeold;
};

float IRAM_ATTR control(MotorDC &obj, float y);
void IRAM_ATTR encoderHandler(MotorDC &motor, int i);

#endif