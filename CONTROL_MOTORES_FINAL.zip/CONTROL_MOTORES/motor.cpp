// motor.cpp

#include "motor.h"

float IRAM_ATTR control(MotorDC &obj, float y) {
  // float e = obj.ref - y;
  // obj.Ts = (millis() - obj.timeold) / 1000.0;
  // obj.Aka += e * obj.Ts;
  // float de = (e - obj.ea) / obj.Ts;
  // float u = obj.kp * e + obj.ki*obj.Aka + obj.kd * de;
  // obj.timeold = millis();
  // obj.ea = e;

  // if (u > 255) {
  //   u = 255;
  // } else if (u < -255) {
  //   u = -255;
  // }

  // return u;

  // Error actual
  float e = obj.ref - y;

  // Tiempo actual y tiempo de muestreo en segundos
  unsigned long now = millis();
  obj.Ts = (now - obj.timeold) / 1000.0;

  // Evitar división por cero o pasos de tiempo demasiado pequeños
  if (obj.Ts < 0.001) obj.Ts = 0.001;

  // Derivada del error con filtro simple (factor alfa entre 0 y 1)
  float alpha = 0.1;
  float de_raw = (e - obj.ea) / obj.Ts;
  float de_filtered = alpha * de_raw + (1 - alpha) * de_filtered;

  // Integración del error (anti-windup simple: solo si control no saturado antes)
  float u_unsat = obj.kp * e + obj.ki * obj.Aka + obj.kd * de_filtered;

  // Controlar la acumulación del error integral
  if (u_unsat < 255 && u_unsat > -255) {
    obj.Aka += e * obj.Ts;
  }

  // Control final usando la integral actualizada
  float u = obj.kp * e + obj.ki * obj.Aka + obj.kd * de_filtered;

  // Saturación
  if (u > 255) u = 255;
  else if (u < -255) u = -255;

  // Actualización para próxima iteración
  obj.ea = e;
  obj.timeold = now;

  return u;
}


void IRAM_ATTR encoderHandler(MotorDC &motor, int i){
  
  int ANow = digitalRead(motor.A);
  int BNow = digitalRead(motor.B);

  if(motor.bandera && (motor.counter<0)){
    motor.counter = 0;
    }else if(!motor.bandera && motor.counter>0){
      motor.counter = 0;
      }
    
  
  if(ANow == 0 && BNow == 0){
    if(motor.Aval == 0 && motor.Bval == 1){
      motor.counter++;
      motor.bandera = true;
      }else if(motor.Aval == 1 && motor.Bval == 0){
        motor.counter--;
        motor.bandera = false;
        }
  }else if(ANow == 1 && BNow == 0){
    if(motor.Aval == 0 && motor.Bval == 0){
      motor.counter++;
      motor.bandera = true;
      }else if(motor.Aval == 1 && motor.Bval == 1){
        motor.counter--;
        motor.bandera = false;
        }
    }else if(ANow == 1 && BNow == 1){
      if(motor.Aval == 1 && motor.Bval == 0){
        motor.counter++;
        motor.bandera = true;
      }else if(motor.Aval == 0 && motor.Bval == 1){
        motor.counter--;
        motor.bandera = false;
        }
      }else if(ANow == 0 && BNow == 1){
        if(motor.Aval == 1 && motor.Bval == 1){
          motor.counter++;
          motor.bandera = true;
        }else if(motor.Aval == 0 && motor.Bval == 0){
        motor.counter--;
        motor.bandera = false;
        }
      }

  motor.Aval = ANow;
  motor.Bval = BNow;  
}
