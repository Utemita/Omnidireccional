import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
import math

class OdomSubscriber(Node):
    def __init__(self):
        super().__init__('odom_listener')
        self.subscription = self.create_subscription(
            Odometry,
            '/odom',
            self.odom_callback,
            10
        )
        self.subscription  # prevent unused variable warning

    def odom_callback(self, msg):
        # Posición
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y

        # Cuaternion a ángulo (theta)
        theta = msg.pose.pose.orientation.z
        self.get_logger().info(f"x: {x:.2f}, y: {y:.2f}, theta: {theta:.2f} rad")

def main(args=None):
    rclpy.init(args=args)
    node = OdomSubscriber()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
