import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from geometry_msgs.msg import Pose
from nav_msgs.msg import Odometry
import math
import matplotlib.pyplot as plt
import time

class OmniController(Node):
    def __init__(self):
        
        super().__init__('omni_controller')

        self.x_data = []
        self.y_data = []
        self.t_data = []


        self.start_time = time.time()

        # Parametros del robot 
        self.l  = 0.101
        self.b  = 0.101
        self.r  = 0.04
        
        self.xd_a = 0
        self.yd_a = 0
        self.thetad_a = 0
        
        # Estado del robot
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0

        self.odom_sub = self.create_subscription(Odometry, '/odom', self.odom_callback, 10)
        self.pd_sub = self.create_subscription(Pose, '/pd', self.pd_callback, 10)
        
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        # Control: publicar cada 100 ms
        self.timer = self.create_timer(0.1, self.control_loop)

    def pd_callback(self, msg):
        # Posición y orientación del robot
        self.xd_a = msg.position.x
        self.yd_a = msg.position.y

        # Convertir orientación en quaternion a ángulo theta
        self.thetad_a = msg.orientation.z

        self.get_logger().info(f'Posición deseada: x={self.xd_a:.2f}, y={self.yd_a:.2f}, theta={self.thetad_a:.2f}°')
        # self.get_logger().info(f'Posición deseada: theta={math.degrees(self.theta):.2f}°')

    def odom_callback(self, msg):
        # Posición y orientación del robot
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y

        self.theta = msg.pose.pose.orientation.z

        t = time.time() - self.start_time
        self.t_data.append(t)
        
        self.x_data.append(self.x)
        self.y_data.append(self.y)

        self.get_logger().info(f'ODOM: x={self.x:.2f}, y={self.y:.2f}, theta={math.degrees(self.theta):.2f}°')
        # self.get_logger().info(f'ODOM: theta={math.degrees(self.theta):.2f}°')

    def control_loop(self):
        cmd = Twist()

        # Valores deseados
        xd  = self.xd_a
        yd  = self.yd_a
        thd = math.radians(self.thetad_a)

        th = self.theta

        # Control cinematico
        k  = 0.3
        ux  = -k*(self.x-self.xd_a) 
        uy  = -k*(self.y-self.yd_a)
        uth = -k*(th-thd)
        
        # if math.fabs(self.x-self.xd_a) < 0.03:
        #     ux = 0.0
        
        # if math.fabs(self.y-self.yd_a) < 0.03:
        #     uy = 0.0
        
        # if math.fabs(th-thd) < 0.2:
        #     uth = 0.0

        # self.get_logger().info(f'ux={ux:.6f}, uy={uy:.6f}, uth={uth:.6f}')
        
        Vf = ux*math.cos(th) + uy*math.sin(th)
        Vl = -ux*math.sin(th) + uy*math.cos(th)
        W  = uth
          
        cmd.linear.x = Vf
        cmd.linear.y = Vl
        cmd.angular.z = W 
        
        self.cmd_pub.publish(cmd)
        # self.get_logger().info(f'cmd_vel: x={cmd.linear.x:.2f}, y={cmd.linear.y:.2f}, z={cmd.angular.z:.2f}')
    
    def plot_xy_vs_time(self):
        plt.rcParams.update({'font.size': 20})  # Aumentar tamaño de fuente

        plt.figure()
        plt.plot(self.t_data, self.x_data, label='x(t)', color='blue', linewidth=2)
        plt.plot(self.t_data, self.y_data, label='y(t)', color='green', linewidth=2)

        plt.title('Posición del robot en x, y')
        plt.xlabel('Tiempo [s]')
        plt.ylabel('Posición [m]')
        plt.grid(True)
        plt.legend()
        plt.tight_layout()
        plt.show()


def main(args=None):
    rclpy.init(args=args)
    node = OmniController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.plot_xy_vs_time()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()


